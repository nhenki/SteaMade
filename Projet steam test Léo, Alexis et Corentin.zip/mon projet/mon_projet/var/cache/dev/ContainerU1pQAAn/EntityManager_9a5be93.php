<?php

namespace ContainerU1pQAAn;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{

    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder4da1c = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializer5ac8a = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiesd4167 = [
        
    ];

    public function getConnection()
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'getConnection', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'getMetadataFactory', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'getExpressionBuilder', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'beginTransaction', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->beginTransaction();
    }

    public function getCache()
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'getCache', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->getCache();
    }

    public function transactional($func)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'transactional', array('func' => $func), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->transactional($func);
    }

    public function commit()
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'commit', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->commit();
    }

    public function rollback()
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'rollback', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'getClassMetadata', array('className' => $className), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'createQuery', array('dql' => $dql), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'createNamedQuery', array('name' => $name), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'createQueryBuilder', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'flush', array('entity' => $entity), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'clear', array('entityName' => $entityName), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->clear($entityName);
    }

    public function close()
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'close', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->close();
    }

    public function persist($entity)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'persist', array('entity' => $entity), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'remove', array('entity' => $entity), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'refresh', array('entity' => $entity), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'detach', array('entity' => $entity), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'merge', array('entity' => $entity), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'getRepository', array('entityName' => $entityName), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'contains', array('entity' => $entity), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'getEventManager', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'getConfiguration', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'isOpen', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'getUnitOfWork', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'getProxyFactory', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'initializeObject', array('obj' => $obj), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'getFilters', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'isFiltersStateClean', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'hasFilters', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return $this->valueHolder4da1c->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializer5ac8a = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder4da1c) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder4da1c = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder4da1c->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, '__get', ['name' => $name], $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        if (isset(self::$publicPropertiesd4167[$name])) {
            return $this->valueHolder4da1c->$name;
        }

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder4da1c;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    get_parent_class($this),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
            return;
        }

        $targetObject = $this->valueHolder4da1c;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder4da1c;

            $targetObject->$name = $value; return $targetObject->$name;
            return;
        }

        $targetObject = $this->valueHolder4da1c;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value; return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, '__isset', array('name' => $name), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder4da1c;

            return isset($targetObject->$name);
            return;
        }

        $targetObject = $this->valueHolder4da1c;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, '__unset', array('name' => $name), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder4da1c;

            unset($targetObject->$name);
            return;
        }

        $targetObject = $this->valueHolder4da1c;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __clone()
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, '__clone', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        $this->valueHolder4da1c = clone $this->valueHolder4da1c;
    }

    public function __sleep()
    {
        $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, '__sleep', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;

        return array('valueHolder4da1c');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer5ac8a = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer5ac8a;
    }

    public function initializeProxy() : bool
    {
        return $this->initializer5ac8a && ($this->initializer5ac8a->__invoke($valueHolder4da1c, $this, 'initializeProxy', array(), $this->initializer5ac8a) || 1) && $this->valueHolder4da1c = $valueHolder4da1c;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder4da1c;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder4da1c;
    }


}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
