<?php

namespace App\Controller;

use App\Entity\Article;
use App\Form\SearchJeuxType;
use App\Repository\JeuxRepository;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class BRController extends AbstractController
{
    /**
     * @Route("/br", name="b_r")
     */
    public function index(): Response
    {
        $repo = $this->getDoctrine()->getRepository(Article::class);
        $jeux = $repo->findAll();

        return $this->render('br/index.html.twig', [
            'controller_name' => 'BRController',
            'jeux' => $jeux
        ]);
    }

    /**
     * @Route("/recherche", name="Recherche")
     */
    public function Recherche(JeuxRepository $jeuxRepository, Request $request) {

        $jeux = $jeuxRepository->findBy(['id' => true],['name' => 'desc'], 5);

        $form = $this->createForm(SearchJeuxType::class);

        $search = $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){
            $jeux = $jeuxRepository->search($search->get('mots')->getData());
        }

        return $this->render('br/BarreDeRecherche.html.twig',[
            'jeux' => $jeux,
            'form' => $form->createView()]);
    }
}
