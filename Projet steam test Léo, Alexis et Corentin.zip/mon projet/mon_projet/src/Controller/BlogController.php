<?php

namespace App\Controller;

use App\Entity\User;
use App\Form\EditPasswordType;
use App\Form\EditProfileType;
use App\Form\RegistrationType;

use Doctrine\ORM\EntityManagerInterface;
use Psr\Container\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;

class BlogController extends AbstractController
{
     /**
     * @Route("/profile", name="mon_profil")
     */
    public function account()
    {
        return $this->render('blog/account.html.twig');
    }

    /**
     * @Route("/profile/modify", name="modifier_mon_profil")
     */
    public function modifierinfos(Request $request, EntityManagerInterface $manager)
    {
        $user = $this->getUser();
        $form = $this->createForm(EditProfileType::class, $user);

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){


            $manager->persist($user);
            $manager->flush();

            $this->addFlash('message', 'Profil mis à jour');
            return $this->redirectToRoute('mon_profil');
        }

        return $this->render('blog/modify_account.html.twig', [
            'form' => $form->createView()]);
    }

    /**
     * @Route("/profile/modify_password", name="modifier_mon_mot_de_passe")
     * @param Request $request
     * @param EntityManagerInterface $manager
     * @param $encoder
     * @return \Symfony\Component\HttpFoundation\RedirectResponse|Response
     */
    public function modifiermotdepasse(Request $request, EntityManagerInterface $manager,UserPasswordEncoderInterface $encoder)
    {
        $user = $this->getUser();
        $form = $this->createForm(EditPasswordType::class, $user);

        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){
            $hash = $encoder->encodePassword($user, $user->getPassword());

            $user->setPassword($hash);

            $manager->persist($user);
            $manager->flush();

            $this->addFlash('message', 'Mot de passe mis à jour');
            return $this->redirectToRoute('mon_profil');
        }

        return $this->render('blog/modify_password.html.twig', [
            'form' => $form->createView()]);
    }


}
