<?php

namespace App\Controller;



use Doctrine\ORM\EntityManager;
use Doctrine\ORM\EntityManagerInterface;
use Doctrine\Persistence\ObjectManager;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

use App\Entity\Article;
use App\Repository\ArticleRepository;

class JeuxController extends AbstractController
{
    /**
     * @Route("/blog", name="blog")
     */
    public function index(): Response
    {
        $repo = $this->getDoctrine()->getRepository(Article::class);
        $articles = $repo->findAll();
        return $this->render('jeux/index.html.twig', [
            'controller_name' => 'JeuxController',
            'articles' => $articles
        ]);
    }

    /**
     * @Route("/", name="home")
     */
    public function home() {
        return $this->render('blog/home.html.twig', [
            'title' => "bienvenu chaccal",
        ]);


    }
    /**
    * @Route("/blog/new", name="blog_poster")
     * @Route("/blog/{id}/edit" , name="blog_edit")
    */
    public function form(Article $article = null, Request $request, EntityManagerInterface $manager) {

        if(!$article) {
            $article =  new Article();
        }



        $form = $this->createFormBuilder($article)
                     ->add('title', TextType::class, ['attr' => ['placeholder' => "Tire du Jeu", 'class' => 'form_control']])
                     ->add('content', TextType::class, ['attr' => ['placeholder' => "résumé du jeu", 'class' => 'form_control']])
                     ->add('image', TextType::class, ['attr' => ['placeholder' => "Image de l'article", 'class' => 'form_control']])
                     ->add('lien', TextType::class, ['attr' => ['placeholder' => "Lien de telechargement", 'class' => 'form_control']])
                     ->add('save' , submitType::class,['label' => 'enregistrer'])
                     ->getForm();
        $form->handleRequest($request);

        if($form->isSubmitted() && $form->isValid()){
            if(!$article->getId()) {
                $article->setCreatedAt(new \DateTime());
            }

            $manager->persist($article);
            $manager->flush();

            return $this->redirectToRoute('jeux_vue', ['id' => $article->getId()]);
        }

        return $this->render('jeux/poster.html.twig', ['formJeu' => $form->createView(), 'editMode' => $article->getId() !== null]);
    }


    /**
     * @Route("/blog/{id}" , name="jeux_vue")
     */
    public function show($id){
        $repo =  $this->getDoctrine()->getRepository(Article::class);
        $article = $repo->find($id);
        return $this->render('jeux/show.html.twig', ['article' => $article]);
    }


}
